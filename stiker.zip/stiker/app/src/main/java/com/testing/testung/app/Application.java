package com.testing.testung.app;

import android.support.multidex.MultiDex;
import android.support.multidex.MultiDexApplication;

import com.orhanobut.hawk.Hawk;

public class Application extends MultiDexApplication {

    @Override
    public void onCreate() {
        super.onCreate();
        Hawk.init(this).build();
        MultiDex.install(this);
    }
}
